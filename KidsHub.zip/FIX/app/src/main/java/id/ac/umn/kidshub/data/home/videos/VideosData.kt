package id.ac.umn.kidshub.data.home.videos

data class VideosData(
    val id: String,
    val title: String,
    val thumbnail: String,
    val url: String,
    val code: String,
    val description: String,
    val uploader: String,
)