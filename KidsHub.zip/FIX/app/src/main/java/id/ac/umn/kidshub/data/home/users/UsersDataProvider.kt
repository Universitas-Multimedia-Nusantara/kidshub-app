package id.ac.umn.kidshub.data.home.users

object UsersDataProvider {
    val usersData = UsersData(
        userId = "",
        firstName = "",
        lastName = "",
        email = "",
        password = "",
        role = "",
        exp = 0,
    )
}