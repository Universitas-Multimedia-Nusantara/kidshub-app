package id.ac.umn.kidshub.data.home.videos

object VideosDataProvider {
    val videosDataList = mutableListOf<VideosData>()
}