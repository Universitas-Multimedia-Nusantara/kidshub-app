package id.ac.umn.kidshub.data.home.books

object BooksDataProvider {
        val booksDataList = mutableListOf<BooksData>()
}